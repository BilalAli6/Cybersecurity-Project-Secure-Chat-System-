import os
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import random
import socket

# Manual Diffie-Hellman parameters
p = 23  # Prime number
g = 5   # Base (generator)

SALT_LENGTH = 32

# ANSI escape sequences for colors
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"

def diffie_hellman_key_exchange(client_socket):

    print(f"\n{CYAN}>>> Now performing Diffie-Hellman key exchange...{RESET}")
    private_key = random.randint(1, p - 1)
    public_key = pow(g, private_key, p)
    
    print(f"\n\n{CYAN}>>> Server's Public Key: {public_key}{RESET}\n")

    client_public_key = int(client_socket.recv(1024).decode())
    print(f"{CYAN}>>> Received Client's Public Key: {client_public_key}{RESET}\n")
    
    client_socket.send(str(public_key).encode())

    shared_secret = pow(client_public_key, private_key, p)
    print(f"{CYAN}>>> Shared Secret: {shared_secret}{RESET}\n")
    return shared_secret

def derive_aes_key(shared_secret, username):
    mutual_key = f"{username}{shared_secret}"
    aes_key = hashlib.sha256(mutual_key.encode()).digest()[:16]
    return aes_key

def aes_encrypt(data, key):
    iv = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(data.encode('utf-8'), AES.block_size))
    
    # Showing AES encryption details
    print(f"\n{MAGENTA}>>> Performing AES encryption...{RESET}")
    print(f"{CYAN}>>> Original Text: {data}{RESET}")
    print(f"{CYAN}>>> Encrypted Text (hex): {ciphertext.hex()}{RESET}")
    
    return iv + ciphertext

def aes_decrypt(ciphertext, key):
    iv = ciphertext[:16]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = unpad(cipher.decrypt(ciphertext[16:]), AES.block_size)
    
    # Showing AES decryption details
    print(f"\n{MAGENTA}>>> Performing AES decryption...{RESET}")
    print(f"{CYAN}>>> Encrypted Text (hex): {ciphertext[16:].hex()}{RESET}")
    print(f"{CYAN}>>> Decrypted Text: {plaintext.decode('utf-8')}{RESET}")
    
    return plaintext.decode('utf-8')


def hash_password(password):
    salt = get_random_bytes(SALT_LENGTH).hex()
    hashed_password = hashlib.sha256((password + salt).encode()).hexdigest()
    return hashed_password, salt

def store_credentials(email, username, password):
    hashed_password, salt = hash_password(password)
    with open("creds.txt", "a") as f:
        f.write(f"email: {email}, username: {username}, password: {hashed_password}, salt: {salt}\n")

def check_credentials(username, password):
    if not os.path.exists("creds.txt"):
        return False

    with open("creds.txt", "r") as f:
        for line in f:
            parts = line.strip().split(", ")
            stored_username = parts[1].split(": ")[1]
            stored_password = parts[2].split(": ")[1]
            salt = parts[3].split(": ")[1]
            hashed_input_password = hashlib.sha256((password + salt).encode()).hexdigest()
            if stored_username == username and stored_password == hashed_input_password:
                return True
    return False

def handle_client(client_socket):
    shared_secret = diffie_hellman_key_exchange(client_socket)

    while True:
        try:
            encrypted_data = client_socket.recv(1024)
            if not encrypted_data:
                break

            data = aes_decrypt(encrypted_data, hashlib.sha256(str(shared_secret).encode()).digest()[:16])

            if data.startswith("register:"):
                _, user_details = data.split("register:")
                email, username, password = user_details.split(',')
                if check_credentials(username, password):
                    response = f"{RED}Error: Username already exists.{RESET}"
                else:
                    store_credentials(email, username, password)
                    response = f"{GREEN}Registration successful.{RESET}"

            elif data.startswith("login:"):
                _, user_details = data.split("login:")
                username, password = user_details.split(',')
                if check_credentials(username, password):
                    response = f"\n\t{GREEN}<<< Login successful >>>{RESET}\n"
                    client_socket.send(aes_encrypt(response, hashlib.sha256(str(shared_secret).encode()).digest()[:16]))

                    # After login, perform new Diffie-Hellman exchange for chat encryption
                    shared_secret = diffie_hellman_key_exchange(client_socket)
                    aes_key = derive_aes_key(shared_secret, username)

                    # Chat Phase - Two-way communication
                    while True:
                        # Receive and decrypt client message
                        encrypted_message = client_socket.recv(1024)
                        if not encrypted_message:
                            break

                        message = aes_decrypt(encrypted_message, aes_key)
                        print(f"\n{YELLOW}>>> Client: {message}{RESET}")

                        if message.lower() == 'bye':
                            print(f"{RED}\n>>> Client has disconnected......{RESET}\n")
                            client_socket.close()
                            return  # Exit function after closing

                        # Server sends reply
                        server_message = input(f"{YELLOW}>>> Enter your message to the client (type 'bye' to quit): {RESET}")
                        if server_message.lower() == 'bye':
                            client_socket.send(aes_encrypt('bye', aes_key))
                            client_socket.close()
                            return  # Exit function after closing

                        encrypted_reply = aes_encrypt(server_message, aes_key)
                        client_socket.send(encrypted_reply)

                else:
                    response = f"{RED}Error: Invalid credentials.{RESET}"

            encrypted_response = aes_encrypt(response, hashlib.sha256(str(shared_secret).encode()).digest()[:16])
            client_socket.send(encrypted_response)

        except (OSError, ConnectionResetError) as e:
            print(f"{RED}Connection error: {e}{RESET}")
            client_socket.close()
            break

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('', 8080))
    server_socket.listen(5)
    print(f"\t{MAGENTA} *** <<<< SECURE ENCRYPTED CHAT SYSTEM >>>> ***{RESET}\n")
    print(f"{GREEN}Server is listening on port 8080{RESET}\n")

    while True:
        try:
            client_socket, client_address = server_socket.accept()
            print(f"{CYAN}New connection established from {client_address}{RESET}\n")

            # Create a new process to handle the client
            pid = os.fork()
            if pid == -1:
                print(f"{RED}Error! Unable to fork process.{RESET}")
            elif pid == 0:
                server_socket.close()  # Close the server socket in the child process
                handle_client(client_socket)
                os._exit(0)  # Exit child process after handling
            else:
                client_socket.close()  # Close the client socket in the parent process
        except KeyboardInterrupt:
            server_socket.close()
            break
    print("\n\n-----------------------------------------------------********----------------------------------------------------")        
    print(f"{MAGENTA}>>>>> This chat was secured using AES encryption and the keys were exchanged using the Diffie-Hellman method <<<<<{RESET}")
    print("-----------------------------------------------------********----------------------------------------------------\n\n")     

start_server()
