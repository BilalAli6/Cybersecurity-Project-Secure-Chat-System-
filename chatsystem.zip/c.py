import socket
import os
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import random

# Manual Diffie-Hellman parameters
p = 23  # Prime number (keep it larger in real cases)
g = 5   # Base (generator)

# ANSI escape sequences for colors
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"

def create_socket():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('localhost', 8080)
    sock.connect(server_address)
    return sock

def diffie_hellman_key_exchange(sock):

    print(f"\n{CYAN}>>> Now performing Diffie-Hellman key exchange...{RESET}")
    private_key = random.randint(1, p - 1)
    public_key = pow(g, private_key, p)
    
    print(f"\n{CYAN}>>> Client's Public Key: {public_key}{RESET}\n")

    sock.send(str(public_key).encode())
    server_public_key = int(sock.recv(1024).decode())
    print(f"{CYAN}>>> Received Server's Public Key: {server_public_key}{RESET}\n")

    shared_secret = pow(server_public_key, private_key, p)
    print(f"{CYAN}>>> Shared Secret: {shared_secret}{RESET}\n")

    return shared_secret

def derive_aes_key(shared_secret, username):

    mutual_key = f"{username}{shared_secret}"
    aes_key = hashlib.sha256(mutual_key.encode()).digest()[:16]  # 128-bit AES key
    return aes_key

def aes_encrypt(data, key):
    iv = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(data.encode('utf-8'), AES.block_size))
    
    # Showing AES encryption details
    print(f"\n{MAGENTA}>>> Performing AES encryption...{RESET}")
    print(f"{CYAN}>>> Original Text: {data}{RESET}")
    print(f"{CYAN}>>> Encrypted Text (hex): {ciphertext.hex()}{RESET}")
    
    return iv + ciphertext

def aes_decrypt(ciphertext, key):
    iv = ciphertext[:16]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = unpad(cipher.decrypt(ciphertext[16:]), AES.block_size)
    
    # Showing AES decryption details
    print(f"\n{MAGENTA}>>> Performing AES decryption...{RESET}")
    print(f"{CYAN}>>> Encrypted Text (hex): {ciphertext[16:].hex()}{RESET}")
    print(f"{CYAN}>>> Decrypted Text: {plaintext.decode('utf-8')}{RESET}")
    
    return plaintext.decode('utf-8')


def main():

    print(f"\t {MAGENTA}*** <<<< SECURE ENCRYPTED CHAT SYSTEM >>>> ***{RESET}\n")
    sock = create_socket()
    shared_secret = diffie_hellman_key_exchange(sock)

    while True:
        print(f"{YELLOW}>>>---------------------------------------------<<<{RESET}")
        choice = input(f"{YELLOW}>>> Press 1 to Register and 2 to LOGIN: {RESET}")
        print(f"{YELLOW}>>>---------------------------------------------<<<{RESET}")

        if choice == '1':
            username = input(f"{GREEN}>>> Enter username: {RESET}")
            email = input(f"{GREEN}>>> Enter email: {RESET}")
            password = input(f"{GREEN}>>> Enter password: {RESET}")
            data = f"register:{email},{username},{password}"

        elif choice == '2':
            username = input(f"{GREEN}\n\t>>> Enter username: {RESET}")
            password = input(f"{GREEN}\t>>> Enter password: {RESET}")
            data = f"login:{username},{password}"

        else:
            print(f"{RED}>>> Invalid choice. Please enter 1 or 2.{RESET}\n")
            continue

        initial_aes_key = hashlib.sha256(str(shared_secret).encode()).digest()[:16]
        encrypted_data = aes_encrypt(data, initial_aes_key)
        sock.send(encrypted_data)

        response = aes_decrypt(sock.recv(1024), initial_aes_key)
        print(f"\n{GREEN}>>> Server Response: {response}{RESET}")

        if 'Login successful' in response:
            shared_secret = diffie_hellman_key_exchange(sock)
            aes_key = derive_aes_key(shared_secret, username)
            break

    print(f"{GREEN}You can now start sending and receiving encrypted messages:{RESET}\n")

    chat_history = []

    while True:
        try:
            message = input(f"{GREEN}>>> Enter your message to the server (type 'bye' to quit): {RESET}")
            if message.lower() == 'bye':
                sock.send(aes_encrypt('bye', aes_key))
                sock.close()
                break

            encrypted_message = aes_encrypt(message, aes_key)
            sock.send(encrypted_message)

            encrypted_reply = sock.recv(1024)
            if not encrypted_reply:
                break

            server_reply = aes_decrypt(encrypted_reply, aes_key)
            print(f"{GREEN}>>> Server: {server_reply}{RESET}")

            chat_history.append(f"You: {message}")
            chat_history.append(f"Server: {server_reply}")

            if server_reply.lower() == 'exit':
                print(f"{RED}\t\n<<< Server ended the chat >>>{RESET}\n")
                sock.close()
                break

        except KeyboardInterrupt:
            sock.close()
            break

    print("\n--- Chat History ---")
    for entry in chat_history:
        print(entry)
        
    print("\n\n-----------------------------------------------------********----------------------------------------------------")        
    print(f"{MAGENTA}>>>>> This chat was secured using AES encryption and the keys were exchanged using the Diffie-Hellman method <<<<<{RESET}")
    print("-----------------------------------------------------********----------------------------------------------------\n\n") 

main()
